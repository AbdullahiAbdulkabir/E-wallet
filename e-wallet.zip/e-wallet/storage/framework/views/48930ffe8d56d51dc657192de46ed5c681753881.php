<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <?php if($message = Session::get('success')): ?>
                <div class="custom-alerts alert alert-success fade in">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
                    <?php echo $message; ?>

                </div>
                <?php Session::forget('success');?>
                <?php endif; ?>

                <?php if($message = Session::get('error')): ?>
                <div class="custom-alerts alert alert-danger fade in">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
                    <?php echo $message; ?>

                </div>
                <?php Session::forget('error');?>
                <?php endif; ?>
                <div class="panel-heading">Paywith Paystack</div>
                <div class="panel-body">
                        <form method="POST" action="<?php echo e(route('pay')); ?>" accept-charset="UTF-8" class="form-horizontal" role="form">
                                <div class="row" style="margin-bottom:40px;">
                                  <div class="col-md-8 col-md-offset-2">
                                    <p>
                                        <div>
                                            Lagos Eyo Print Tee Shirt
                                            ₦ 2,950
                                        </div>
                                    </p>
                                    <input type="hidden" name="email" value="otemuyiwa@gmail.com"> 
                                    <input type="hidden" name="orderID" value="345">
                                    <input type="hidden" name="amount" value="800"> 
                                    <input type="hidden" name="quantity" value="3">
                                    <input type="hidden" name="metadata" value="<?php echo e(json_encode($array = ['key_name' => 'value',])); ?>" > 
                                    <input type="hidden" name="reference" value="<?php echo e(Paystack::genTranxRef()); ?>"> 
                                    <input type="hidden" name="key" value="<?php echo e(config('paystack.secretKey')); ?>"> 
                                    <?php echo e(csrf_field()); ?> 
                        
                                     <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
                        
                        
                                    <p>
                                      <button class="btn btn-success btn-lg btn-block" type="submit" value="Pay Now!">
                                      <i class="fa fa-plus-circle fa-lg"></i> Pay Now!
                                      </button>
                                    </p>
                                  </div>
                                </div>
                        </form>       
     <?php $__env->stopSection(); ?>
<?php echo $__env->make('clients.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>